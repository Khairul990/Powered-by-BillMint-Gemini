import React, { useState } from 'react';
import { AuthProvider, useAuth } from './context/AuthContext';
import { SubscriptionProvider } from './context/SubscriptionContext';
import Layout from './components/Layout';
import Spline from '@splinetool/react-spline';
import { 
  Plus, 
  ArrowRight, 
  CheckCircle2, 
  Zap, 
  Shield, 
  BarChart3,
  CreditCard,
  X,
  Mail,
  Lock,
  User as UserIcon,
  Loader2
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

// lazy path imports for pages
import Dashboard from './pages/Dashboard';
import Invoices from './pages/Invoices';
import Customers from './pages/Customers';
import Expenses from './pages/Expenses';
import Inventory from './pages/Inventory';
import Settings from './pages/Settings';
import AdminPanel from './pages/AdminPanel';

const LandingPage = () => {
  const { login, loginWithEmail, register, resetPassword } = useAuth();
  const [showLogin, setShowLogin] = useState(false);
  const [authMode, setAuthMode] = useState<'signin' | 'signup' | 'forgot'>('signin');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const [error, setError] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [resetSent, setResetSent] = useState(false);

  const handleGoogleSignIn = async () => {
    try {
      setError('');
      setIsSubmitting(true);
      await login();
      setShowLogin(false);
    } catch (e: any) {
      if (e.code === 'auth/operation-not-allowed') {
        setError('Google Sign-in is not enabled. Please enable it in the Firebase Console (Authentication > Sign-in method).');
      } else {
        setError(e.message || 'Failed to sign in');
      }
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleEmailAuth = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setIsSubmitting(true);
    try {
      if (authMode === 'signin') {
        await loginWithEmail(email, password);
      } else if (authMode === 'signup') {
        await register(email, password, name);
      } else {
        await resetPassword(email);
        setResetSent(true);
      }
      if (authMode !== 'forgot') {
        setShowLogin(false);
      }
    } catch (e: any) {
      if (e.code === 'auth/operation-not-allowed') {
        setError('Email/Password authentication is not enabled. Please enable it in the Firebase Console (Authentication > Sign-in method).');
      } else {
        setError(e.message || 'Authentication failed');
      }
    } finally {
      setIsSubmitting(false);
    }
  };

  const toggleMode = (mode: 'signin' | 'signup' | 'forgot') => {
    setAuthMode(mode);
    setError('');
    setResetSent(false);
  };

  return (
    <div className="min-h-screen bg-white">
      <nav className="w-full sticky top-0 z-50 bg-white/70 backdrop-blur-xl border-b border-slate-200/50 shadow-[0_10px_30px_-10px_rgba(0,0,0,0.05)]">
        <div className="max-w-7xl mx-auto px-6 py-4 flex justify-between items-center">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-gradient-to-b from-emerald-400 to-emerald-600 rounded-xl flex items-center justify-center text-white font-bold shadow-[0_4px_0_rgb(4,120,87)]">B</div>
            <span className="text-xl font-bold tracking-tight text-slate-900">BillMint</span>
          </div>
          <button 
            onClick={() => setShowLogin(true)}
            className="px-6 py-2.5 bg-gradient-to-b from-slate-700 to-slate-900 text-white rounded-full font-bold shadow-[0_4px_0_rgb(15,23,42)] active:translate-y-[4px] active:shadow-[0_0px_0_rgb(15,23,42)] transition-all"
          >
            Get Started
          </button>
        </div>
      </nav>

      <main>
        <section className="max-w-7xl mx-auto px-6 pt-10 pb-32 flex flex-col-reverse lg:flex-row items-center gap-12 text-center lg:text-left">
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6 }}
            className="flex-1"
          >
            <span className="inline-block px-4 py-1.5 bg-emerald-50 text-emerald-600 rounded-full text-sm font-semibold mb-6">
              Simplifying Business Billing
            </span>
            <h1 className="text-5xl md:text-7xl font-bold text-slate-900 tracking-tight leading-[1.1] mb-8">
              Professional Billing <br />
              <span className="text-emerald-500">Managed by BillMint.</span>
            </h1>
            <p className="text-xl text-slate-600 max-w-2xl mx-auto lg:mx-0 mb-10">
              Create gorgeous invoices, track business expenses, and manage your clients with the most intuitive billing platform on the market.
            </p>
            <div className="flex flex-col sm:flex-row items-center justify-center lg:justify-start gap-4">
              <button 
                onClick={() => setShowLogin(true)}
                className="w-full sm:w-auto px-8 py-4 bg-gradient-to-b from-emerald-400 to-emerald-600 border-t border-emerald-300/50 text-white rounded-2xl font-bold text-lg shadow-[0_8px_0_rgb(4,120,87),0_15px_30px_-5px_rgba(16,185,129,0.4)] active:translate-y-[8px] active:shadow-[0_0px_0_rgb(4,120,87),0_0px_0_rgba(16,185,129,0)] hover:brightness-110 transition-all flex items-center justify-center gap-2"
              >
                Start Invoicing Now <ArrowRight size={20} />
              </button>
              <button className="w-full sm:w-auto px-8 py-4 bg-white border border-slate-200 text-slate-700 rounded-2xl font-bold text-lg shadow-[0_8px_0_rgb(226,232,240)] active:translate-y-[8px] active:shadow-[0_0px_0_rgb(226,232,240)] transition-all hover:bg-slate-50">
                View Demo
              </button>
            </div>
          </motion.div>

          {/* 3D Spline Scene */}
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="flex-1 w-full h-[400px] md:h-[500px] lg:h-[600px] relative rounded-[2.5rem] overflow-hidden group cursor-grab active:cursor-grabbing shadow-[0_30px_60px_-15px_rgba(16,185,129,0.3)] bg-gradient-to-tr from-emerald-50 to-white"
          >
            {/* Overlay gradient to blend edges slightly */}
            <div className="absolute inset-0 bg-gradient-to-tr from-white/40 to-transparent pointer-events-none z-10 rounded-[2.5rem] shadow-inner" />
            <Spline 
              scene="https://prod.spline.design/6Wq1Q7YGyM-iab9i/scene.splinecode" 
              className="w-full h-full object-cover" 
            />
          </motion.div>
        </section>

        {/* Features Preview */}
        <section className="bg-slate-50 py-24">
          <div className="max-w-7xl mx-auto px-6">
            <div className="grid md:grid-cols-3 gap-8">
              {[
                { icon: Zap, title: "Lightning Fast", desc: "Create and send professional invoices in under 60 seconds." },
                { icon: BarChart3, title: "Smart Tracking", desc: "Keep a pulse on your business with real-time revenue and expense analytics." },
                { icon: Shield, title: "Secure & Reliable", desc: "Your business data is safely stored and always accessible from any device." }
              ].map((f, i) => (
                <div key={i} className="bg-gradient-to-b from-white to-slate-50 p-8 rounded-3xl border border-white shadow-[0_20px_40px_-15px_rgba(0,0,0,0.05),0_0_0_1px_rgba(0,0,0,0.03)] hover:-translate-y-3 hover:rotate-1 hover:shadow-[0_30px_60px_-15px_rgba(0,0,0,0.1),0_0_0_1px_rgba(0,0,0,0.03)] transition-all duration-300">
                  <div className="w-14 h-14 bg-gradient-to-br from-emerald-100 to-emerald-200 shadow-inner rounded-2xl flex items-center justify-center text-emerald-600 mb-6">
                    <f.icon size={26} strokeWidth={2.5} />
                  </div>
                  <h3 className="text-xl font-bold text-slate-800 mb-3">{f.title}</h3>
                  <p className="text-slate-500 leading-relaxed font-medium">{f.desc}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Pricing */}
        <section className="py-24 max-w-5xl mx-auto px-6 text-center">
            <h2 className="text-4xl font-bold text-slate-900 mb-16">Simple, Transparent Pricing</h2>
            <div className="grid md:grid-cols-2 gap-8 max-w-3xl mx-auto text-left">
                {/* Free */}
                <div className="p-8 rounded-3xl bg-gradient-to-b from-white to-slate-50 shadow-[0_20px_40px_-15px_rgba(0,0,0,0.05),0_0_0_1px_rgba(0,0,0,0.03)] border-t border-white flex flex-col">
                    <h3 className="text-lg font-bold text-slate-900 mb-2">Free Plan</h3>
                    <p className="text-4xl font-black mb-6 drop-shadow-sm">₹0 <span className="text-lg font-bold text-slate-400">/ forever</span></p>
                    <ul className="space-y-4 mb-8 flex-1">
                        <li className="flex items-center gap-3 text-slate-700 font-medium"><div className="w-6 h-6 rounded-full bg-emerald-100 flex items-center justify-center"><CheckCircle2 size={16} className="text-emerald-600"/></div> 5 Invoices Free</li>
                        <li className="flex items-center gap-3 text-slate-700 font-medium"><div className="w-6 h-6 rounded-full bg-emerald-100 flex items-center justify-center"><CheckCircle2 size={16} className="text-emerald-600"/></div> Basic Design</li>
                        <li className="flex items-center gap-3 text-slate-700 font-medium"><div className="w-6 h-6 rounded-full bg-emerald-100 flex items-center justify-center"><CheckCircle2 size={16} className="text-emerald-600"/></div> Limited Access</li>
                    </ul>
                    <button onClick={() => setShowLogin(true)} className="w-full py-4 bg-white border-2 border-slate-200 rounded-2xl font-bold text-slate-700 shadow-[0_6px_0_rgb(226,232,240)] active:translate-y-[6px] active:shadow-none transition-all">Choose Free</button>
                </div>
                {/* Premium */}
                <div className="p-8 rounded-3xl bg-gradient-to-br from-slate-800 to-slate-900 text-white relative overflow-hidden shadow-[0_30px_60px_-15px_rgba(0,0,0,0.3),inset_0_1px_0_rgba(255,255,255,0.1)] flex flex-col hover:-translate-y-2 transition-all">
                    <div className="absolute top-6 right-6 bg-emerald-500 text-white text-xs font-bold px-4 py-1.5 rounded-full uppercase tracking-wider shadow-[0_0_20px_rgba(16,185,129,0.5)]">Popular</div>
                    <h3 className="text-lg font-bold mb-2">Premium Plan</h3>
                    <p className="text-4xl font-black mb-6 drop-shadow-md">₹99 <span className="text-lg font-bold text-slate-400">/ month</span></p>
                    <ul className="space-y-4 mb-8 flex-1">
                        <li className="flex items-center gap-3 text-slate-200 font-medium"><div className="w-6 h-6 rounded-full bg-emerald-500/20 flex items-center justify-center"><CheckCircle2 size={16} className="text-emerald-400"/></div> Unlimited Invoices</li>
                        <li className="flex items-center gap-3 text-slate-200 font-medium"><div className="w-6 h-6 rounded-full bg-emerald-500/20 flex items-center justify-center"><CheckCircle2 size={16} className="text-emerald-400"/></div> Custom Logo Upload</li>
                        <li className="flex items-center gap-3 text-slate-200 font-medium"><div className="w-6 h-6 rounded-full bg-emerald-500/20 flex items-center justify-center"><CheckCircle2 size={16} className="text-emerald-400"/></div> Expense Tracking</li>
                        <li className="flex items-center gap-3 text-slate-200 font-medium"><div className="w-6 h-6 rounded-full bg-emerald-500/20 flex items-center justify-center"><CheckCircle2 size={16} className="text-emerald-400"/></div> WhatsApp Reminders</li>
                    </ul>
                    <button onClick={() => setShowLogin(true)} className="w-full py-4 bg-gradient-to-b from-emerald-400 to-emerald-600 border-t border-emerald-300 text-white rounded-2xl font-bold shadow-[0_6px_0_rgb(4,120,87)] active:translate-y-[6px] active:shadow-none hover:brightness-110 transition-all">Go Premium</button>
                </div>
            </div>
        </section>
        
        {/* Registration Section */}
        <section id="signup" className="py-24 bg-gradient-to-br from-emerald-400 to-emerald-600 text-white relative overflow-hidden">
          <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/cubes.png')] opacity-10 mix-blend-overlay"></div>
          <div className="max-w-4xl mx-auto px-6 grid md:grid-cols-2 gap-12 items-center relative z-10">
            <div>
              <h2 className="text-4xl font-black mb-6 drop-shadow-md">Ready to transform your billing?</h2>
              <p className="text-emerald-50 text-lg mb-8 font-medium drop-shadow-sm">Join thousands of businesses that trust BillMint for their financial management. Create your free account in seconds.</p>
              <ul className="space-y-4">
                <li className="flex items-center gap-3">
                  <div className="w-8 h-8 bg-white/20 backdrop-blur shadow-inner rounded-full flex items-center justify-center"><CheckCircle2 size={16} /></div>
                  <span className="font-semibold text-white/90">No credit card required for free plan</span>
                </li>
                <li className="flex items-center gap-3">
                  <div className="w-8 h-8 bg-white/20 backdrop-blur shadow-inner rounded-full flex items-center justify-center"><CheckCircle2 size={16} /></div>
                  <span className="font-semibold text-white/90">Instant access to all basic features</span>
                </li>
                <li className="flex items-center gap-3">
                  <div className="w-8 h-8 bg-white/20 backdrop-blur shadow-inner rounded-full flex items-center justify-center"><CheckCircle2 size={16} /></div>
                  <span className="font-semibold text-white/90">Professional invoices in minutes</span>
                </li>
              </ul>
            </div>
            <div className="bg-gradient-to-b from-white to-slate-50 p-8 rounded-[2.5rem] text-slate-900 shadow-[0_20px_40px_-5px_rgba(0,0,0,0.3),_0_0_0_1px_rgba(255,255,255,0.1)] border-t border-white/60">
              <h3 className="text-2xl font-black mb-6 text-center text-slate-800">Create Free Account</h3>
              <div className="space-y-6">
                <button 
                  onClick={() => { setShowLogin(true); setAuthMode('signup'); }}
                  className="w-full py-4 bg-gradient-to-b from-emerald-400 to-emerald-600 text-white rounded-2xl font-bold text-lg shadow-[0_8px_0_rgb(4,120,87),0_15px_30px_-5px_rgba(16,185,129,0.4)] active:translate-y-[8px] active:shadow-none hover:brightness-110 transition-all flex items-center justify-center gap-2 border-t border-emerald-300"
                >
                  Get Started for Free <ArrowRight size={20} />
                </button>
                <p className="text-center text-sm text-slate-500 font-semibold">
                  Already have an account? <button onClick={() => { setShowLogin(true); setAuthMode('signin'); }} className="text-emerald-500 font-bold hover:text-emerald-600 transition-colors">Sign In</button>
                </p>
              </div>
            </div>
          </div>
        </section>

        {/* Simple Contact Form */}
        <section id="contact" className="py-24 max-w-3xl mx-auto px-6">
          <div className="bg-gradient-to-tr from-white to-slate-50 p-10 rounded-[2.5rem] shadow-[0_20px_50px_-15px_rgba(0,0,0,0.05),0_0_0_1px_rgba(0,0,0,0.03)] border-t border-white">
            <h2 className="text-3xl font-black text-slate-900 mb-4 text-center">Get in Touch</h2>
            <p className="text-slate-500 mb-8 text-center font-medium">Have questions or need help? Send us a message.</p>
            
            <form className="space-y-5" onSubmit={(e) => {
              e.preventDefault();
              alert('Message sent! We will get back to you soon.');
              (e.target as HTMLFormElement).reset();
            }}>
              <div className="grid md:grid-cols-2 gap-5">
                <div className="space-y-2">
                  <label className="text-sm font-bold text-slate-700 ml-1">Name</label>
                  <input 
                    type="text" 
                    placeholder="Your Name" 
                    className="w-full px-5 py-4 bg-slate-50 shadow-inner border border-slate-200 rounded-xl focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 focus:bg-white outline-none transition-all font-medium text-slate-700"
                    required
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-bold text-slate-700 ml-1">Email</label>
                  <input 
                    type="email" 
                    placeholder="Email Address" 
                    className="w-full px-5 py-4 bg-slate-50 shadow-inner border border-slate-200 rounded-xl focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 focus:bg-white outline-none transition-all font-medium text-slate-700"
                    required
                  />
                </div>
              </div>
              <div className="space-y-2">
                <label className="text-sm font-bold text-slate-700 ml-1">Subject</label>
                <input 
                  type="text" 
                  placeholder="How can we help?" 
                  className="w-full px-5 py-4 bg-slate-50 shadow-inner border border-slate-200 rounded-xl focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 focus:bg-white outline-none transition-all font-medium text-slate-700"
                  required
                />
              </div>
              <div className="space-y-2">
                <label className="text-sm font-bold text-slate-700 ml-1">Message</label>
                <textarea 
                  placeholder="Your message here..."
                  rows={4}
                  className="w-full px-5 py-4 bg-slate-50 shadow-inner border border-slate-200 rounded-xl focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 focus:bg-white outline-none transition-all resize-none font-medium text-slate-700"
                  required
                ></textarea>
              </div>
              <button 
                type="submit"
                className="w-full py-4 bg-gradient-to-b from-slate-800 to-slate-900 border-t border-slate-700 text-white rounded-2xl font-bold shadow-[0_6px_0_rgb(15,23,42)] active:translate-y-[6px] active:shadow-none transition-all hover:brightness-110"
              >
                Send Message
              </button>
            </form>
          </div>
        </section>

      </main>

      {/* Google Sign-in Login Card Modal */}
      <AnimatePresence>
        {showLogin && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => !isSubmitting && setShowLogin(false)}
              className="absolute inset-0 bg-slate-900/60 backdrop-blur-md"
            />
            <motion.div 
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              className="relative bg-white w-full max-w-md rounded-[2.5rem] shadow-2xl p-8 md:p-10 flex flex-col items-center border border-slate-100"
            >
              <button 
                onClick={() => setShowLogin(false)}
                disabled={isSubmitting}
                className="absolute top-6 right-6 p-2 text-slate-400 hover:text-slate-600 bg-slate-50 hover:bg-slate-100 rounded-full transition-colors disabled:opacity-50"
              >
                <X size={20} />
              </button>

              <div className="w-16 h-16 bg-gradient-to-b from-emerald-400 to-emerald-600 border-t border-emerald-300 rounded-2xl flex items-center justify-center text-white font-bold text-3xl shadow-[0_8px_0_rgb(4,120,87),0_15px_30px_-5px_rgba(16,185,129,0.4)] mb-8 shrink-0">B</div>
              
              <h2 className="text-2xl font-bold text-slate-900 mb-2">
                {authMode === 'signin' ? 'Welcome Back' : authMode === 'signup' ? 'Create Account' : 'Reset Password'}
              </h2>
              <p className="text-slate-500 mb-8 text-sm">
                {authMode === 'signin' ? 'Sign in to continue to BillMint' : authMode === 'signup' ? 'Start your specialized billing journey' : 'Enter your email to receive reset link'}
              </p>

              {error && (
                <div className="w-full p-3 bg-red-50 text-red-600 text-sm rounded-xl mb-6 border border-red-100 animate-shake">
                  {error}
                </div>
              )}

              {resetSent ? (
                <div className="w-full p-4 bg-emerald-50 text-emerald-700 text-sm rounded-2xl mb-6 border border-emerald-100 text-center">
                  Password reset link sent to your email!
                  <button 
                    onClick={() => toggleMode('signin')}
                    className="block mx-auto mt-2 font-bold underline"
                  >
                    Back to Sign In
                  </button>
                </div>
              ) : (
                <form onSubmit={handleEmailAuth} className="w-full space-y-4">
                  {authMode === 'signup' && (
                    <div className="relative group">
                      <UserIcon className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 group-focus-within:text-emerald-500 transition-colors" size={18} />
                      <input 
                        type="text" 
                        placeholder="Full Name"
                        value={name}
                        onChange={(e) => setName(e.target.value)}
                        className="w-full py-3.5 pl-12 pr-4 bg-slate-50 border border-slate-100 rounded-2xl focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 transition-all"
                        required
                      />
                    </div>
                  )}
                  
                  <div className="relative group">
                    <Mail className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 group-focus-within:text-emerald-500 transition-colors" size={18} />
                    <input 
                      type="email" 
                      placeholder="Email Address"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      className="w-full py-3.5 pl-12 pr-4 bg-slate-50 border border-slate-100 rounded-2xl focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 transition-all"
                      required
                    />
                  </div>

                  {authMode !== 'forgot' && (
                    <div className="relative group">
                      <Lock className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 group-focus-within:text-emerald-500 transition-colors" size={18} />
                      <input 
                        type="password" 
                        placeholder="Password"
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                        className="w-full py-3.5 pl-12 pr-4 bg-slate-50 border border-slate-100 rounded-2xl focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 transition-all"
                        required
                      />
                    </div>
                  )}

                  {authMode === 'signin' && (
                    <div className="text-right">
                      <button 
                        type="button"
                        onClick={() => toggleMode('forgot')}
                        className="text-xs font-semibold text-emerald-600 hover:text-emerald-700"
                      >
                        Forgot Password?
                      </button>
                    </div>
                  )}

                  <button 
                    type="submit"
                    disabled={isSubmitting}
                    className="w-full py-4 bg-gradient-to-b from-emerald-400 to-emerald-600 border-t border-emerald-300 text-white rounded-2xl font-bold shadow-[0_6px_0_rgb(4,120,87)] active:translate-y-[6px] active:shadow-none hover:brightness-110 transition-all disabled:opacity-50 flex items-center justify-center gap-2"
                  >
                    {isSubmitting ? <Loader2 className="animate-spin" size={20} /> : (authMode === 'signin' ? 'Sign In' : authMode === 'signup' ? 'Create Account' : 'Send Link')}
                  </button>
                </form>
              )}
              
              <div className="w-full flex items-center gap-4 my-6">
                <div className="h-px flex-1 bg-slate-100"></div>
                <span className="text-xs font-bold text-slate-400 uppercase tracking-widest">or</span>
                <div className="h-px flex-1 bg-slate-100"></div>
              </div>

              <button 
                onClick={handleGoogleSignIn}
                disabled={isSubmitting}
                className="w-full py-4 px-6 bg-white border-2 border-slate-100 hover:border-emerald-500 hover:bg-emerald-50 rounded-2xl font-bold text-slate-700 transition-all flex items-center justify-center gap-3 relative overflow-hidden disabled:opacity-50"
              >
                <svg viewBox="0 0 24 24" width="22" height="22" xmlns="http://www.w3.org/2000/svg">
                  <path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" fill="#4285F4"/>
                  <path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853"/>
                  <path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z" fill="#FBBC05"/>
                  <path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" fill="#EA4335"/>
                </svg>
                Continue with Google
              </button>

              <div className="mt-8 text-sm">
                {authMode === 'signin' ? (
                  <p className="text-slate-500">
                    Don't have an account? {' '}
                    <button onClick={() => toggleMode('signup')} className="font-bold text-emerald-600 hover:underline">Create one</button>
                  </p>
                ) : (
                  <p className="text-slate-500">
                    Already have an account? {' '}
                    <button onClick={() => toggleMode('signin')} className="font-bold text-emerald-600 hover:underline">Sign In</button>
                  </p>
                )}
              </div>
              
              <p className="text-[10px] text-slate-400 mt-8 uppercase tracking-widest leading-relaxed">
                By continuing, you agree to our <br />
                <a href="#" className="underline hover:text-slate-600 transition-colors">Terms of Service</a> & <a href="#" className="underline hover:text-slate-600 transition-colors">Privacy Policy</a>
              </p>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
      
      <footer className="max-w-7xl mx-auto px-6 py-12 border-t border-slate-100 text-center">
        <div className="flex items-center justify-center space-x-2 mb-4">
          <div className="w-6 h-6 bg-emerald-500 rounded flex items-center justify-center text-white font-bold text-xs">B</div>
          <span className="text-lg font-bold tracking-tight">BillMint</span>
        </div>
        <p className="text-slate-400 text-sm">© 2026 BillMint. All rights reserved. The ultimate billing solution for modern businesses.</p>
        <p className="text-slate-300 text-[10px] mt-4 uppercase tracking-[0.2em]">Powered by BillMint Engine</p>
      </footer>
    </div>
  );
};

const AuthenticatedApp = () => {
    const [activeTab, setActiveTab] = useState('dashboard');
    
    const renderContent = () => {
        switch(activeTab) {
            case 'dashboard': return <Dashboard />;
            case 'invoices': return <Invoices />;
            case 'customers': return <Customers />;
            case 'inventory': return <Inventory />;
            case 'expenses': return <Expenses />;
            case 'settings': return <Settings />;
            case 'admin': return <AdminPanel />;
            default: return <Dashboard />;
        }
    };

    return (
        <Layout activeTab={activeTab} setActiveTab={setActiveTab}>
            {renderContent()}
        </Layout>
    );
};

const Root = () => {
  const { user, loading } = useAuth();

  if (loading) return (
    <div className="h-screen w-full flex items-center justify-center bg-white">
      <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-emerald-500"></div>
    </div>
  );

  return user ? <AuthenticatedApp /> : <LandingPage />;
};

export default function App() {
  return (
    <AuthProvider>
      <SubscriptionProvider>
        <Root />
      </SubscriptionProvider>
    </AuthProvider>
  );
}
